const express = require('express');
const helmet = require('helmet');
const cors = require('cors');

const app = express();
app.use(helmet());
app.use(cors());
app.use(express.json());

app.get('/api/health', (req, res) => res.json({status: 'ok'}));

app.get('/api/projects', (req, res) => {
  res.json([
    {id:'p1', title:'Educação para Todos', summary:'Aulas de reforço para crianças.'},
    {id:'p2', title:'Horta Comunitária', summary:'Alimentação saudável e sustentável.'}
  ]);
});

app.post('/api/donations/create', (req, res) => {
  const { projectId, amount } = req.body;
  // Em produção: criar PaymentIntent no Stripe e salvar no DB
  res.json({ success: true, clientSecret: 'simulado_client_secret' });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`API rodando na porta ${PORT}`));
