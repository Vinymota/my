-- Schema simplificado (PostgreSQL)
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT,
  role VARCHAR(20) NOT NULL,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE ngos (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT,
  mission TEXT,
  contact JSONB,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE projects (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  ngo_id UUID REFERENCES ngos(id),
  title TEXT,
  summary TEXT,
  goal_amount NUMERIC,
  raised_amount NUMERIC DEFAULT 0,
  start_date DATE,
  end_date DATE,
  status TEXT,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE donations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id UUID REFERENCES projects(id),
  user_id UUID REFERENCES users(id),
  amount NUMERIC NOT NULL,
  currency CHAR(3) DEFAULT 'BRL',
  payment_status VARCHAR(20),
  payment_provider TEXT,
  payment_reference TEXT,
  created_at TIMESTAMP DEFAULT now()
);
