// Demo: carregar projetos de exemplo
document.getElementById('year').textContent = new Date().getFullYear();
const projects = [
  {id:'p1', title:'Educação para Todos', summary:'Aulas de reforço para crianças.'},
  {id:'p2', title:'Horta Comunitária', summary:'Alimentação saudável e sustentável.'},
  {id:'p3', title:'Oficinas de Emprego', summary:'Capacitação profissional.'}
];
const ul = document.querySelector('.projects-grid');
projects.forEach(p=>{
  const li = document.createElement('li');
  li.className = 'card';
  li.innerHTML = `<h3>${p.title}</h3><p>${p.summary}</p><a href="#" class="btn-small">Saiba mais</a>`;
  ul.appendChild(li);
});
