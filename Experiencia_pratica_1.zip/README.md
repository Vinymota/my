# Experiência Prática 1 - Plataforma para ONGs

Projeto completo (prototipo + backend) preparado para submissão e deploy.

## Conteúdo do repositório

- `frontend/` - HTML, CSS e JavaScript (estático) - protótipo mobile-first
- `backend/` - Node.js + Express (esqueleto) com endpoints principais
- `sql/` - Esquema SQL (PostgreSQL) para criar as tabelas principais
- `docs/Plataforma_ONG_Projeto_Completo.pdf` - Documento técnico (gerado)
- `openapi.yaml` - Especificação OpenAPI (endpoints principais)
- `.github/workflows/ci.yml` - Exemplo de workflow CI para testes e build

## Como rodar localmente

### Pré-requisitos
- Node.js (v18+)
- npm ou yarn
- PostgreSQL (opcional para testes)
- Git

### Rodando o frontend (estático)
```bash
# abrir a pasta frontend no navegador ou usar um server estático:
cd frontend
# com Python 3:
python -m http.server 3000
# abrir http://localhost:3000
```

### Rodando o backend (desenvolvimento)
```bash
cd backend
npm install
# criar arquivo .env com as variáveis (ex.: DATABASE_URL, JWT_SECRET)
npm run dev
# API disponível em http://localhost:4000
```

### Subir para o GitHub (comandos)
```bash
git init
git add .
git commit -m "Initial commit - Experiencia_pratica_1"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/Experiencia_pratica_1.git
git push -u origin main
```

> Substitua `SEU_USUARIO` pelo seu usuário no GitHub. Se preferir, crie o repositório no GitHub web e siga as instruções de push que ele fornece.

